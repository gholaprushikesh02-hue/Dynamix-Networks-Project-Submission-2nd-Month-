const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const fetch = require("node-fetch");
const cors = require("cors");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

app.use(express.json());
app.use(cors());
app.use(express.static("public"));

const JWT_SECRET = "secret123";
const users = [];

// 🌍 TRANSLATION
async function translateText(text, targetLang) {
  const res = await fetch("https://libretranslate.de/translate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      q: text,
      source: "auto",
      target: targetLang,
      format: "text"
    })
  });
  const data = await res.json();
  return data.translatedText;
}

/* ================= AUTH ================= */

app.post("/api/register", async (req, res) => {
  const { name, email, password, lang } = req.body;
  const hash = await bcrypt.hash(password, 10);
  users.push({ name, email, password: hash, lang });
  res.json({ msg: "Registered" });
});

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);
  if (!user) return res.status(401).json({ msg: "User not found" });

  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ msg: "Wrong password" });

  const token = jwt.sign(
    { email: user.email, name: user.name, lang: user.lang },
    JWT_SECRET
  );

  res.json({ token });
});

/* ================= SOCKET ================= */

io.use((socket, next) => {
  try {
    socket.user = jwt.verify(socket.handshake.auth.token, JWT_SECRET);
    next();
  } catch {
    next(new Error("Unauthorized"));
  }
});

io.on("connection", socket => {
  console.log("Connected:", socket.user.name);

  socket.on("chat_message", async data => {
    const translated = await translateText(
      data.message,
      socket.user.lang
    );

    io.emit("chat_message", {
      user: socket.user.name,
      translated,
      lang: socket.user.lang
    });
  });

  socket.on("disconnect", () => {
    console.log("Disconnected");
  });
});

server.listen(3000, () =>
  console.log("Server running http://localhost:3000")
);

