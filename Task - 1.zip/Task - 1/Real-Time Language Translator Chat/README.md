# Real-Time Language Translator Chat

Project for Dynamic Networks internship task.

## Features
- Real-time chat with Socket.io
- Automatic translation via an external API
- JWT based authentication
- Simple frontend (Vanilla JS)

## Run
1. `npm install`
2. create `.env` (see `.env.example`)
3. `npm start`
4. Open `http://localhost:3000`

## Notes
- The translation module uses LibreTranslate by default. Replace `TRANSLATE_API_URL` and `TRANSLATE_API_KEY` in `.env` for other providers.
- For per-recipient translation you can expand `socketHandler.js` to translate separately for each connected user and emit to individual sockets.
