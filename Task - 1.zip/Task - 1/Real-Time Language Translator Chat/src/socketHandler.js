const { Server } = require('socket.io');
const { translateText } = require('./translate');
const Message = require('../models/Message');
const User = require('../models/User');

function initSocket(server) {
  const io = new Server(server, {
    cors: { origin: '*' }
  });

  io.on('connection', (socket) => {
    console.log('Socket connected:', socket.id);

    // join a room
    socket.on('joinRoom', ({ room, userId }) => {
      socket.join(room);
      socket.room = room;
      socket.userId = userId;
      console.log(`${userId} joined ${room}`);
    });

    // handle sendMessage
    // payload: { text, room, senderId, senderName, targetLang (optional) }
    socket.on('sendMessage', async (payload) => {
      try {
        const { text, room, senderId } = payload;
        // determine recipients' language — for simplicity we will broadcast translated version per recipient language:
        // Here: get room members? We'll simplify: translate to room default language or broadcast both original and auto-translated english.
        // For demonstration, translate into English and broadcast both original and translated.

        // Optionally get sender user language
        const sender = await User.findById(senderId).lean().exec().catch(()=>null);

        // For demonstration: translate to English OR if sender language != 'en' then translate to 'en'
        // In real app: you should translate to each recipient's preferred language separately before emitting individually.
        const targetLang = payload.targetLang || 'en';

        const translated = await translateText(text, 'auto', targetLang);

        // save message
        const msgDoc = new Message({
          senderId,
          senderName: payload.senderName || (sender && sender.name) || 'Anonymous',
          room,
          originalText: text,
          translatedText: translated,
          targetLang
        });
        await msgDoc.save().catch(()=>null);

        // Emit message with both original and translated text
        io.to(room).emit('message', {
          senderId,
          senderName: msgDoc.senderName,
          originalText: text,
          translatedText: translated,
          targetLang,
          createdAt: msgDoc.createdAt
        });

      } catch (err) {
        console.error('sendMessage error', err);
      }
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected', socket.id);
    });
  });
}

module.exports = { initSocket };
