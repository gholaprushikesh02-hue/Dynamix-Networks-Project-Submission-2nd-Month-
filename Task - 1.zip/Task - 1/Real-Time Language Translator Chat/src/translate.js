const fetch = require('node-fetch');

const TRANSLATE_API_URL = process.env.TRANSLATE_API_URL || 'https://libretranslate.de/translate';
const TRANSLATE_API_KEY = process.env.TRANSLATE_API_KEY || '';

async function translateText(text, source, target) {
  // if source is 'auto' you can pass auto, librtranslate supports auto
  try {
    const res = await fetch(TRANSLATE_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(TRANSLATE_API_KEY ? { 'x-api-key': TRANSLATE_API_KEY } : {})
      },
      body: JSON.stringify({
        q: text,
        source: source || 'auto',
        target: target,
        format: 'text'
      })
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Translate API error: ${errText}`);
    }
    const data = await res.json();
    // LibreTranslate returns { translatedText: "..." }
    return data.translatedText || (data.data && data.data.translations && data.data.translations[0].translatedText) || '';
  } catch (err) {
    console.error('translateText error', err);
    // fallback: return original
    return text;
  }
}

module.exports = { translateText };

