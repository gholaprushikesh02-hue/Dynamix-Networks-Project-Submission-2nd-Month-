// CHAT.JS (MESSAGES + ROOMS)
document.addEventListener("DOMContentLoaded", () => {

  // If server not running, disable socket features
  let socket;
  try {
    socket = io();
  } catch (e) {
    alert("Socket.io server not running!");
    return;
  }

  const joinBtn = document.getElementById("join-room");
  const logoutBtn = document.getElementById("logout");
  const sendBtn = document.getElementById("send");

  const msgInput = document.getElementById("msg");
  const messagesDiv = document.getElementById("messages");
  const roomInput = document.getElementById("room");
  const targetLang = document.getElementById("compose-target");

  let currentRoom = "general";

  // Join Room
  joinBtn.onclick = () => {
    currentRoom = roomInput.value.trim();
    if (!currentRoom) {
      alert("Enter room name");
      return;
    }

    socket.emit("join_room", currentRoom);
    messagesDiv.innerHTML += `<p><em>Joined room: ${currentRoom}</em></p>`;
  };

  // Send Message
  sendBtn.onclick = () => {
    const text = msgInput.value.trim();
    if (!text) return;

    const translated = `[${targetLang.value}] ${text}`;

    socket.emit("chat_msg", {
      room: currentRoom,
      translated
    });

    messagesDiv.innerHTML += `<p><strong>You:</strong> ${translated}</p>`;
    msgInput.value = "";
  };

  // Receive Message
  socket.on("chat_msg", (data) => {
    messagesDiv.innerHTML += `<p><strong>Other:</strong> ${data.translated}</p>`;
  });

  // Logout
  logoutBtn.onclick = () => {
    location.reload();
  };

});

