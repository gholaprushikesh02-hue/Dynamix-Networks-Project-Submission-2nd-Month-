document.addEventListener("DOMContentLoaded", () => {

  const nameInput = document.getElementById("name");
  const emailInput = document.getElementById("email");
  const passwordInput = document.getElementById("password");
  const togglePassBtn = document.getElementById("toggle-pass");

  const btnRegister = document.getElementById("btn-register");
  const btnLogin = document.getElementById("btn-login");

  const languageSelect = document.getElementById("language");

  const authDiv = document.getElementById("auth");
  const chatArea = document.getElementById("chat-area");

  let usersDB = [];

  // Show / Hide password
  togglePassBtn.onclick = () => {
    if (passwordInput.type === "password") {
      passwordInput.type = "text";
      togglePassBtn.innerText = "Hide";
    } else {
      passwordInput.type = "password";
      togglePassBtn.innerText = "Show";
    }
  };

  // Register
  btnRegister.onclick = () => {
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();
    const lang = languageSelect.value;

    if (!name || !email || !password) {
      alert("Fill all fields");
      return;
    }

    usersDB.push({ name, email, password, lang });
    alert("Registered successfully");
  };

  // Login
  btnLogin.onclick = () => {
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    const user = usersDB.find(
      u => u.email === email && u.password === password
    );

    if (!user) {
      alert("Invalid credentials");
      return;
    }

    authDiv.classList.add("hidden");
    chatArea.classList.remove("hidden");

    document.getElementById("me-name").innerText = user.name;
    document.getElementById("me-email").innerText = user.email;

    localStorage.setItem("token", data.token);

  };

});
