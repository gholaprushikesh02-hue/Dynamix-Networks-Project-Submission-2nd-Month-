const socket = io();

const sendBtn = document.getElementById("send");
const msgInput = document.getElementById("msg");
const messages = document.getElementById("messages");

sendBtn.onclick = () => {
  const message = msgInput.value;
  const user = document.getElementById("username").value;
  const lang = document.getElementById("language").value;

  if (!message || !user) return;

  socket.emit("send-message", {
    message,
    targetLang: lang,
    user
  });

  msgInput.value = "";
};

socket.on("receive-message", data => {
  const div = document.createElement("div");
  div.innerHTML = `
    <b>${data.user}</b>: ${data.translated}
    <small>(${data.lang})</small>
  `;
  messages.appendChild(div);
});